#pragma once
#include "Common/Notification.h"
#include "Function/matrix.h"
#include "Common/Params.h"
#include "Function/Integral.h"
#include "Function/ODE.h"
#include "Function/Root_of_Polynomial.h"
#include "Function/Cond.h"
#include <memory>
//#include "Function/eigenvalue.h"
//#include "Function/curve_fitting.h"
//#include "Function/root_of_matrix.h"

class Model:public Proxy_Notification
{
protected:
    shared_ptr<vector<Point>> points;
    shared_ptr<string> res;
public:
	Model();
	~Model();
    void getPolynomialRoot(const int n, const double c[], const double EPS);
    void getCond_2(Matrix a);
    void getCond_inf(Matrix a);
    void getODE(double(*f)(double t0, double w0), double a, double b, const int step, double ya);
    void getIntegral(double(*f)(double x), const double a, const double b, const double eps);
    void getIntegral(double(*f)(double x), const double a, const double b);
    void getEigenvalue(Matrix a);
    void getMatrixRoot(Matrix a);
    shared_ptr<vector<Point>>& getPoints();
    shared_ptr<string>& getRes();
    string double2string(double res);
};

